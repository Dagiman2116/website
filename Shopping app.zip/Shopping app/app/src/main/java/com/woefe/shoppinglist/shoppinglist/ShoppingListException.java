

package com.woefe.shoppinglist.shoppinglist;

public class ShoppingListException extends Exception {
    public ShoppingListException(String message) {
        super(message);
    }
}
