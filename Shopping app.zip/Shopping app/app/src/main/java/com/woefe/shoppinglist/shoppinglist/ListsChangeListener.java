
package com.woefe.shoppinglist.shoppinglist;


public interface ListsChangeListener {
    void onListsChanged();
}
