

package com.woefe.shoppinglist.shoppinglist;


class UnmarshallException extends Exception {
    public UnmarshallException(String s) {
        super(s);
    }
}
