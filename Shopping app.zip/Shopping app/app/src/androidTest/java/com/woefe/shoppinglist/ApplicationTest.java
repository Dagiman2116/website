

package com.woefe.shoppinglist;

import android.app.Application;



public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super();
    }
}