package com.woefe.shoppinglist;

public class ApplicationTestCase<T> {
}
